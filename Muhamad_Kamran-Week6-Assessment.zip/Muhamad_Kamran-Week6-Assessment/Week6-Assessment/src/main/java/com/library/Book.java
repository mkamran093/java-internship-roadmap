package com.library;

import java.util.Date;

public class Book {

    private int book_id;
    private String isbn;
    private String title;
    private Date publication_year;
    private int available_copies;

    public Book(int book_id, String isbn, String title, Date publication_year, int available_copies) {
        this.book_id = book_id;
        this.isbn = isbn;
        this.title = title;
        this.publication_year = publication_year;
        this.available_copies = available_copies;
    }

    public int getBook_id() {
        return book_id;
    }

    public void setBook_id(int book_id) {
        this.book_id = book_id;
    }

    public String getIsbn() {
        return isbn;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Date getPublication_year() {
        return publication_year;
    }

    public void setPublication_year(Date publication_year) {
        this.publication_year = publication_year;
    }

    public int getAvailable_copies() {
        return available_copies;
    }

    public void setAvailable_copies(int available_copies) {
        this.available_copies = available_copies;
    }
}
