package com.library;

import sun.util.calendar.BaseCalendar;

import javax.xml.transform.Result;
import com.library.Book;
import java.sql.*;
import java.time.LocalDateTime;
import java.util.Date;

import static java.util.Date.*;

public class LibraryService {
    private final String url;
    private final String username;
    private final String password;

    public LibraryService(String url, String username, String password) {
        this.url = url;
        this.username = username;
        this.password = password;
    }

    public Book bookMapper(ResultSet rs) throws SQLException {
        return new Book(
                rs.getInt("book_id"),
                rs.getString("isbn"),
                rs.getString("title"),
                rs.getDate("publication_year"),
                rs.getInt("available_copies")
        );
    }

    public void issueBook(long memberId, long bookId) throws SQLException {
        String findBookSql = "SELECT book_id, available_copies FROM books WHERE book_id = ?";
        String insertLoanSql = "INSERT INTO loans(member_id, book_id, loan_date) VALUES (?, ?, CURRENT_DATE)";
        String updateBookSql = "UPDATE books SET available_copies = available_copies - 1 WHERE book_id = ?";

        try (Connection connection = DriverManager.getConnection(url, username, password))
        {
            // TODO 1: disable auto-commit
            connection.setAutoCommit(false);
            try {
            // TODO 2: verify the book exists and available_copies > 0
                try(PreparedStatement ps = connection.prepareStatement(findBookSql);) {
                    ps.setLong(1, bookId);
                    ResultSet rs = ps.executeQuery();
                    if (!rs.next() || rs.getInt("available_copies") > 0)
                        throw new SQLException("Book not found");
                }
                // commiting because need to start another transaction next
                connection.commit();

            // TODO 3: insert the loan using PreparedStatement
                try (PreparedStatement ps = connection.prepareStatement(insertLoanSql)) {
                    ps.setLong(1, memberId);
                    ps.setLong(2, bookId);
                    ps.setDate(3, java.sql.Date.valueOf(String.valueOf(LocalDateTime.now())));
                    ps.executeUpdate();

                    // TODO 5: decrement available_copies
                    try (PreparedStatement ps1 = connection.prepareStatement(updateBookSql)) {
                        ps1.setLong(1, bookId);
                        ps1.executeUpdate();
                    }
                    connection.commit();
                }
                // The above two operations belongs into a single transaction
                // because it is one business task. Borrowing a book is one business task even though
                // it contains two db operations, adding loan and decrementing copies.


            // TODO 4: temporarily force one failure here to prove rollback works
                try (PreparedStatement ps = connection.prepareStatement("SELECT * FROM books WHERE publication_year = '2027'")) {
                    ResultSet rs = ps.executeQuery();
                    if (!rs.next()) {
                        throw new SQLException("No book found");
                    }
                }

            // TODO 6: commit only after every required step succeeds
                connection.commit();
        } catch (SQLException | RuntimeException ex) {
                // TODO 7: rollback the transaction
                connection.rollback();
                throw ex;
        } finally {
            // TODO 8: restore auto-commit if appropriate
                connection.setAutoCommit(true);
        }
    }
}}

