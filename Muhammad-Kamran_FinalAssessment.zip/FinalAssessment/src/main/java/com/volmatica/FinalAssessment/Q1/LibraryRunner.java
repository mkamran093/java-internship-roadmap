package com.volmatica.FinalAssessment.Q1;

import com.volmatica.FinalAssessment.Q1.service.LibraryService;

import com.volmatica.FinalAssessment.Q1.model.Book;

public class LibraryRunner {
    public static void main(String[] args) {

        LibraryService service = new LibraryService();

        service.addBook(new Book(1, "Java Basics", "James"));
        service.addBook(new Book(2, "Spring Boot", "John"));
        service.addBook(new Book(3, "Java Advanced", "James"));

        System.out.println(service.getLastAddedBook());
        System.out.println(service.sortBooks());
        System.out.println(service.findBooksByAuthor("James"));
    }
}

