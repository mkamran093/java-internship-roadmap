package com.volmatica.FinalAssessment.Q1.service;


import com.volmatica.FinalAssessment.Q1.model.Book;

import java.util.ArrayList;
import java.util.List;

public class LibraryService {

    // TODO: Add collection for books
    List<Book> books = new ArrayList<>();

    public void addBook(Book book) {
        // TODO
        if (book == null) {
            throw new IllegalArgumentException("Book cannot be null");
        }
        books.add(book);
    }

    public Book getLastAddedBook() {
        // TODO
        if(!books.isEmpty()){
            return books.get(books.size() - 1);
        }
        return null;
    }

    public List<Book> sortBooks() {
        // TODO: Sort books by title
        if (books.isEmpty()) return null;
        return books.stream()
                .sorted((b1, b2) -> b1.getTitle().compareTo(b2.getTitle()))
                .toList();
    }

    public List<Book> findBooksByAuthor(String author) {
        // TODO: Return matching books
        if (books.isEmpty()) return null;

        return books.stream()
                .filter(book -> book.getAuthor().equals(author))
                .toList();
    }
}

