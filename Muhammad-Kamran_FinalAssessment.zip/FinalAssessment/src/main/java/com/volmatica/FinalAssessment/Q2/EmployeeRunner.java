package com.volmatica.FinalAssessment.Q2;

import com.volmatica.FinalAssessment.Q2.data.TestData;
import com.volmatica.FinalAssessment.Q2.model.Employee;
import com.volmatica.FinalAssessment.Q2.service.EmployeeService;

import java.util.List;

public class EmployeeRunner {

    public static void main(String[] args) {

        EmployeeService service = new EmployeeService();

        List<Employee> employees = TestData.getEmployees();

        System.out.println("Retirement Report:");
        service.generateRetirementReport(employees)
                .forEach(System.out::println);

        System.out.println("Pension Report:");
        service.generatePensionReport(employees)
                .forEach(System.out::println);

        System.out.println("Probation Report:");
        service.generateProbationReport(employees)
                .forEach(System.out::println);
    }
}
