package com.volmatica.FinalAssessment.Q2.data;

import com.volmatica.FinalAssessment.Q2.model.Employee;

import java.time.LocalDate;
import java.util.List;

public class TestData {

    public static List<Employee> getEmployees() {

        return List.of(
                new Employee(
                        1,
                        "Ali",
                        "IT",
                        LocalDate.of(2024,1,10),
                        LocalDate.of(2029,5,1),
                        null,
                        true
                ),

                new Employee(
                        2,
                        "Sara",
                        "HR",
                        LocalDate.of(2015,3,20),
                        LocalDate.of(2027,6,1),
                        LocalDate.of(2023,1,1),
                        false
                ),

                new Employee(
                        3,
                        "Kamran",
                        "Marketing",
                        LocalDate.of(2015,3,20),
                        LocalDate.of(2027,6,1),
                        LocalDate.of(2023,1,1),
                        true
                ),

                new Employee(
                        4,
                        "Hammad",
                        "Admin",
                        LocalDate.of(2019,3,20),
                        LocalDate.of(2036,6,1),
                        LocalDate.of(2036,1,1),
                        false
                )
        );
    }
}

