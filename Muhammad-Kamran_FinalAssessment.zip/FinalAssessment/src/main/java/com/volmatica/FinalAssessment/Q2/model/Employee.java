package com.volmatica.FinalAssessment.Q2.model;

import java.time.LocalDate;

public class Employee {

    private long id;
    private String name;
    private String department;
    private LocalDate joiningDate;
    private LocalDate retirementDate;
    private LocalDate pensionStartDate;
    private boolean onProbation;

    // TODO: Add constructor
    public Employee() {}

    public Employee(long id, String name, String department, LocalDate joiningDate, LocalDate retirementDate, LocalDate pensionStartDate, boolean onProbation) {
        this.id = id;
        this.name = name;
        this.department = department;
        this.joiningDate = joiningDate;
        this.retirementDate = retirementDate;
        this.pensionStartDate = pensionStartDate;
        this.onProbation = onProbation;
    }

    // TODO: Add getters


    public long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getDepartment() {
        return department;
    }

    public LocalDate getJoiningDate() {
        return joiningDate;
    }

    public LocalDate getRetirementDate() {
        return retirementDate;
    }

    public LocalDate getPensionStartDate() {
        return pensionStartDate;
    }

    public boolean isOnProbation() {
        return onProbation;
    }

    @Override
    public String toString() {
        return "Employee{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", department='" + department + '\'' +
                ", joiningDate=" + joiningDate +
                ", retirementDate=" + retirementDate +
                ", pensionStartDate=" + pensionStartDate +
                ", onProbation=" + onProbation +
                '}';
    }
}

