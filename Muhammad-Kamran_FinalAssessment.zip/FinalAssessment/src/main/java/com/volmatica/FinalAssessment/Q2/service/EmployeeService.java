package com.volmatica.FinalAssessment.Q2.service;

import com.volmatica.FinalAssessment.Q2.model.Employee;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

public class EmployeeService {
    public List<Employee> generateRetirementReport(
            List<Employee> employees) {
        // todo: Return employees retiring within next 5 years
        if(employees.isEmpty() || employees == null) {
            System.out.println("Employee cannot be empty or null");
            return null;
        }

        int year = LocalDate.now().getYear();

        return employees.stream()
                .filter(employee -> employee.getRetirementDate().getYear() - year > 0 && employee.getRetirementDate().getYear() - year < 5)
                .toList();
    }


    public List<Employee> generatePensionReport(
            List<Employee> employees) {
        // TODO:
        // Return employees who started receiving
        // pension within the last 5 years
        if(employees == null || employees.isEmpty()) {
            System.out.println("Employee cannot be empty or null");
            return null;
        }

        return employees.stream()
                .filter(employee -> employee.getPensionStartDate() != null)
                .filter(employee -> LocalDate.now().getYear() - employee.getPensionStartDate().getYear() <= 5)
                .toList();
    }


    public List<Employee> generateProbationReport(
            List<Employee> employees) {

        // TODO:
        // Return employees who joined recently
        // and are currently under probation

        if(employees == null || employees.isEmpty()) {
            System.out.println("Employee cannot be empty or null");
            return null;
        }


        return employees.stream()
                .filter(employee -> employee.getJoiningDate() != null)
                .filter(employee -> LocalDate.now().compareTo(
                        employee.getJoiningDate()) == 1
                        &&
                        employee.isOnProbation()
                )
                .toList();
    }

}

