package com.volmatica.FinalAssessment.Q4;

import com.volmatica.FinalAssessment.Q4.model.BookingRequest;
import com.volmatica.FinalAssessment.Q4.service.BookingService;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class BookingRunner {

    public static void main(String[] args) throws Exception {

        BookingService service = new BookingService();

        ExecutorService executor =
                Executors.newFixedThreadPool(5);


        for (int i = 0; i < 10; i++) {

            executor.submit(() -> {

                service.bookRoom(
                        new BookingRequest(
                                "Customer",
                                "ROOM-101"
                        )
                );

            });
        }


        executor.shutdown();

        System.out.println(
                service.getAvailableRooms()
        );
    }
}

