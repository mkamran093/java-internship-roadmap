package com.volmatica.FinalAssessment.Q4.model;

public class Booking {

    private String roomNumber;
    private String customerName;

    public Booking(String roomNumber, String customerName) {
        this.roomNumber = roomNumber;
        this.customerName = customerName;
    }

    public String getRoomNumber() {
        return roomNumber;
    }

    public String getCustomerName() {
        return customerName;
    }

    @Override
    public String toString() {
        return "Booking{" +
                "roomNumber='" + roomNumber + '\'' +
                ", customerName='" + customerName + '\'' +
                '}';
    }
}
