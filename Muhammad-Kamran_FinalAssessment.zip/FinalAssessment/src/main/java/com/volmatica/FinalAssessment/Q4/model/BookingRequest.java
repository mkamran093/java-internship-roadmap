package com.volmatica.FinalAssessment.Q4.model;

public class BookingRequest {

    private String customerName;
    private String roomNumber;

    // TODO: Add constructor

    public BookingRequest(String customerName, String roomNumber) {
        this.customerName = customerName;
        this.roomNumber = roomNumber;
    }

    // TODO: Add getters

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getRoomNumber() {
        return roomNumber;
    }

    public void setRoomNumber(String roomNumber) {
        this.roomNumber = roomNumber;
    }

    @Override
    public String toString() {
        return "BookingRequest{" +
                "customerName='" + customerName + '\'' +
                ", roomNumber='" + roomNumber + '\'' +
                '}';
    }
}

