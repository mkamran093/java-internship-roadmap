package com.volmatica.FinalAssessment.Q4.model;

public class Room {

    private String roomNumber;
    volatile private boolean booked;

    // TODO: Add constructor
    public Room() {}

    public Room(String roomNumber, boolean booked) {
        this.roomNumber = roomNumber;
        this.booked = booked;
    }

    // TODO: Add getters/setters


    public String getRoomNumber() {
        return roomNumber;
    }

    public void setRoomNumber(String roomNumber) {
        this.roomNumber = roomNumber;
    }

    public boolean isBooked() {
        return booked;
    }

    public void setBooked(boolean booked) {
        this.booked = booked;
    }

    @Override
    public String toString() {
        return "Room{" +
                "roomNumber='" + roomNumber + '\'' +
                ", booked=" + booked +
                '}';
    }
}

