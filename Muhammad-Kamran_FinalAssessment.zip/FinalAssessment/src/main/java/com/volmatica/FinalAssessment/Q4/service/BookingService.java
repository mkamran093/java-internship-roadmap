package com.volmatica.FinalAssessment.Q4.service;

import com.volmatica.FinalAssessment.Q4.model.Booking;
import com.volmatica.FinalAssessment.Q4.model.BookingRequest;
import com.volmatica.FinalAssessment.Q4.model.Room;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class BookingService {

    private final List<Room> rooms;


    public BookingService() {

        // TODO:
        // Initialize rooms
        rooms = new ArrayList<>();
        rooms.add(new Room("101", false));
        rooms.add(new Room("102", false));
        rooms.add(new Room("103", false));
        rooms.add(new Room("104", false));
        rooms.add(new Room("ROOM-101", false));
        rooms.add(new Room("Test-101", false));
    }


    synchronized public Booking bookRoom(
            BookingRequest request) {


        // TODO:
        Optional<Room> check = rooms.stream().filter(room1 -> room1.getRoomNumber().equals(request.getRoomNumber()))
                .findFirst();

        // Check room availability
        if (check.isEmpty()) {
            System.out.println("Room not available");
            throw new RuntimeException("Room Not Available");
        }
        Room room = check.get();

        // Prevent double booking
        // Handle race condition
        Booking booking;

        if (room.isBooked()) {
            System.out.println("Room is already booked");
            throw new RuntimeException("Room is already booked");
        }
        room.setBooked(true);
        booking = new Booking(room.getRoomNumber(), request.getCustomerName());


        // Return booking
        return booking;
    }


    public List<Room> getAvailableRooms() {

        // TODO:
        // Return available rooms
        return rooms.stream()
                .filter(room -> !room.isBooked())
                .toList();
    }
}
