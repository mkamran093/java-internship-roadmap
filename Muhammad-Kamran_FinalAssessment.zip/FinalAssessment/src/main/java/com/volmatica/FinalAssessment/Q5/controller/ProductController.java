package com.volmatica.FinalAssessment.Q5.controller;

import com.volmatica.FinalAssessment.Q5.dto.RequestDTO;
import com.volmatica.FinalAssessment.Q5.dto.ResponseDTO;
import com.volmatica.FinalAssessment.Q5.model.Product;
import com.volmatica.FinalAssessment.Q5.repository.ProductRepository;
import com.volmatica.FinalAssessment.Q5.service.ProductService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/products")
public class ProductController {

    ProductService service;

    public ProductController(ProductService service) {
        this.service = service;
    }

    // TODO:
    // Create endpoint to add product
    // POST /products
    @PostMapping
    public ResponseDTO create(@RequestBody RequestDTO requestDTO) {
        return service.create(requestDTO);
    }


    // TODO:
    // Create endpoint to get/search product
    // GET /products/{id}
    @GetMapping("/{id}")
    public ResponseDTO getById(@PathVariable Long id) {
        return service.getById(id);
    }


    // TODO:
    // Create endpoint to delete product
    // DELETE /products/{id}
    @DeleteMapping
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }

}

