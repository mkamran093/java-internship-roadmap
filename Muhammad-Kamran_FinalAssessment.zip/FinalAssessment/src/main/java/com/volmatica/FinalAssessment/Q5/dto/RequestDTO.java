package com.volmatica.FinalAssessment.Q5.dto;

public record RequestDTO (
        String name,
        Double price
) {
}
