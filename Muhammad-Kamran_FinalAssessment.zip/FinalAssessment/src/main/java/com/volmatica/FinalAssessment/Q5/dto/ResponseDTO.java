package com.volmatica.FinalAssessment.Q5.dto;

public record ResponseDTO(
        Long id,
        String name,
        Double price
) {
}
