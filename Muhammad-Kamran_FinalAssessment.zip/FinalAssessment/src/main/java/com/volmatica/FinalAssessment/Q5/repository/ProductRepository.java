package com.volmatica.FinalAssessment.Q5.repository;

import com.volmatica.FinalAssessment.Q5.model.Product;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Repository
public class ProductRepository {

    private final List<Product> products = new ArrayList<>();

    public void create(Product product) {
        products.add(product);
    }

    public Optional<Product> getById(Long id) {
        return products.stream()
                .filter(product -> product.getId().equals(id))
                .findFirst();
    }

    public void delete(Long id) {
        products.remove(getById(id).orElse(null));
    }

}
