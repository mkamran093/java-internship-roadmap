package com.volmatica.FinalAssessment.Q5.service;

import com.volmatica.FinalAssessment.Q5.dto.RequestDTO;
import com.volmatica.FinalAssessment.Q5.dto.ResponseDTO;
import com.volmatica.FinalAssessment.Q5.model.Product;
import com.volmatica.FinalAssessment.Q5.repository.ProductRepository;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class ProductService {

    private final ProductRepository repository;
    private Long nextId = 1L;

    public ProductService(ProductRepository repository) {
        this.repository = repository;
    }

    public ResponseDTO create(RequestDTO requestDTO) {
        if (requestDTO.name() == null || requestDTO.name().isEmpty()) {
            throw new IllegalArgumentException("Name can't be null or empty");
        }

        if (requestDTO.price() == null) {
            throw new IllegalArgumentException("Price can't be null or empty");
        }

        Product product = new Product(nextId++, requestDTO.name(), requestDTO.price());
        repository.create(product);
        return new ResponseDTO(product.getId(), product.getName(), product.getPrice());

    }

    public ResponseDTO getById(Long id) {

        Product product = repository.getById(id).get();
        return new ResponseDTO(product.getId(), product.getName(), product.getPrice());
    }

    public void delete(Long id) {
        Optional<Product> product = repository.getById(id);
        product.ifPresent((product1) -> {
            repository.delete(product1.getId());
        });
    }
}
