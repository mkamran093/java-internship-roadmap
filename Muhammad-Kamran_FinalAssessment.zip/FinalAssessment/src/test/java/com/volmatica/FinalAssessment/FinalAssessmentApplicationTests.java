package com.volmatica.FinalAssessment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FinalAssessmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
