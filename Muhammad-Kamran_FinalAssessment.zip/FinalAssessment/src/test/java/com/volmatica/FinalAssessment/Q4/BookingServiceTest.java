package com.volmatica.FinalAssessment.Q4;

import com.volmatica.FinalAssessment.Q4.model.Booking;
import com.volmatica.FinalAssessment.Q4.model.BookingRequest;
import com.volmatica.FinalAssessment.Q4.model.Room;
import com.volmatica.FinalAssessment.Q4.service.BookingService;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Assertions.*;

import java.util.List;
import java.util.Optional;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

public class BookingServiceTest {

    BookingService service = new BookingService();
    BookingRequest request = new BookingRequest("Kamran Test", "Test-101");

    @Test
    void booking_success_case() {

        // TODO:
        // Verify room booking works
        Booking booking = service.bookRoom(request);
        Assertions.assertEquals("Test-101", booking.getRoomNumber());
        Assertions.assertEquals("Kamran Test", booking.getCustomerName());

    }


    @Test
    void booking_concurrent_request_case()
            throws Exception {

        // TODO:
        // Create multiple threads
        // Try booking same room
        // Verify only one booking succeeds

        ExecutorService executor =
                Executors.newFixedThreadPool(5);

        for (int i = 0; i < 10; i++) {

            executor.submit(() -> {

                service.bookRoom(
                        new BookingRequest(
                                "Testing",
                                "102"
                        )
                );

            });
        }

        executor.shutdown();
        List<Room> rooms = service.getAvailableRooms();
        Optional<Room> room = rooms.stream()
                .filter(room1 -> room1.getRoomNumber().equals("102"))
                .findFirst();
        Assertions.assertTrue(room.isEmpty());
    }


    @Test
    void booking_failure_case() {

        // TODO:
        // Test unavailable room
        Assertions.assertThrows(RuntimeException.class, () -> service.bookRoom(new BookingRequest("Kamran", "999")));
        // Verify exception handling
        Assertions.assertThrows(RuntimeException.class, () -> service.bookRoom(new BookingRequest("Kamran", "Test-101")));
    }
}

