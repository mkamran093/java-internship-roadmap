package com.example.Week8.Q1.controller;

import com.example.Week8.Q1.service.GreetingService;
import com.example.Week8.Q2.Book;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

@RestController
public class GreetingController {

    private final GreetingService service;

    public GreetingController(GreetingService service) {
        this.service = service;
    }

    @GetMapping("/greet")
    public String greet() {
        return service.greeting("Intern");
    }

}
