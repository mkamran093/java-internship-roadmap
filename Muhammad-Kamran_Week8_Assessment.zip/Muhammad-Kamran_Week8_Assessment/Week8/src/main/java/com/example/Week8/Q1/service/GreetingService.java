package com.example.Week8.Q1.service;

import org.springframework.stereotype.Service;

// @Service marks this class as Spring beans we are expecting it to be injected in GreetingService
// if we remove it, Spring will not find it and give us error like this:
//Description:
//
//        Parameter 0 of constructor in com.example.Week8.Q1.controller.GreetingController required a bean of type 'com.example.Week8.Q1.service.GreetingService' that could not be found.

@Service
public class GreetingService {

    public String greeting(String name) {
        return "Hello, " + name;
    }

}
