package com.example.Week8.Q2;

public record Book(int id, String title, String author) {
}
