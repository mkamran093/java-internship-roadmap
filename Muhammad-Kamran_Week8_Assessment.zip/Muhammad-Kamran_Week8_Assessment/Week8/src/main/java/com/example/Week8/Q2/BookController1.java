package com.example.Week8.Q2;

import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/books")
public class BookController1 {

    List<Book> bookColletions = new ArrayList<>();

    public BookController1() {
        bookColletions.add(new Book(1, "Book1", "Author1"));
        bookColletions.add(new Book(2, "Book2", "Author2"));
        bookColletions.add(new Book(3, "Book3", "Author3"));
        bookColletions.add(new Book(4, "Book4", "Author4"));
        bookColletions.add(new Book(5, "Book5", "Author5"));
    }


    @GetMapping
    public List<Book> getAll() {
        return new ArrayList<>(bookColletions);
    }
    //Sample response
    //[{"id":1,"title":"Book1","author":"Author1"},{"id":2,"title":"Book2","author":"Author2"},{"id":3,"title":"Book3","author":"Author3"},{"id":4,"title":"Book4","author":"Author4"},{"id":5,"title":"Book5","author":"Author5"}]

    @GetMapping("/{id}")
    public Book getById(@PathVariable int id) {
        Book book = bookColletions.stream()
                .filter(book1 -> book1.id() == id)
                .findFirst()
                .orElse(null);
        return book;
    }
    //Sample response:
    // {"id":1,"title":"Book1","author":"Author1"}

    @GetMapping("/search")
    public List<Book> searchBook(@RequestParam String author) {
        return bookColletions.stream()
                .filter(book -> book.author().equals(author))
                .toList();
    }
    // Sample response
    // [{"id":1,"title":"Book1","author":"Author1"}]

}
