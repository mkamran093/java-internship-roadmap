package com.example.Week8.Q3;

import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/books1") // added 1 because it was conflicting with Q2 path
public class BookController {

    private final BookService service;

    public BookController(BookService service) {
        this.service = service;
    }

    @GetMapping
    public List<BookResponse> findAll() {
        return service.getAll();
    }

    @GetMapping("/{id}")
    public BookResponse findById(int id) {
        return service.getById(id);
    }
    //201 Created is the appropriate status code for this endpoint
    //because it is creating a resource.

    @PostMapping
    public BookResponse create(@RequestBody BookRequest request) {
        return service.create(request);
    }
}
