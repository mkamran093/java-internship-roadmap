package com.example.Week8.Q3;

import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

@Repository
public class BookRepository {

    List<Book> books = new ArrayList<>();

    public List<Book> getAll() {
        return new ArrayList<>(books);
    }

    public Book getById(int id) {
        return books.stream()
                .filter(book -> book.getId() == id)
                .findFirst()
                .orElseThrow(() -> new BookNotFoundException("Book with id: " + id + " not found"));
    }

    public void create(Book book) {
        books.add(book);
    }
}
