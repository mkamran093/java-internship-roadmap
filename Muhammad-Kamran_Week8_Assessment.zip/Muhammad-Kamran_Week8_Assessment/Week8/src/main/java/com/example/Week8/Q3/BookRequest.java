package com.example.Week8.Q3;

public record BookRequest (
        String title, String author
){
}
