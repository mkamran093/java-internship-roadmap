package com.example.Week8.Q3;

public record BookResponse (
        int id, String title, String author
){
}
