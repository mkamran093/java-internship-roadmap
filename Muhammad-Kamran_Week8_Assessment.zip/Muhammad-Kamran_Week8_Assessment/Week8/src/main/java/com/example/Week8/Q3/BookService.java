package com.example.Week8.Q3;

import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class BookService {

    private final BookRepository repository;
    private int nextId = 1;

    public BookService(BookRepository repository) {
        this.repository = repository;
    }

    public List<BookResponse> getAll() {
        List<Book> books = repository.getAll();
        List<BookResponse> response = new ArrayList<>();
        for (Book book: books) {
            response.add(new BookResponse(
                    book.getId(),
                    book.getTitle(),
                    book.getAuthor())
            );
        }
        return response;
    }

    public BookResponse getById(int id) {
        Book book = repository.getById(id);
        if (book == null) {
            throw new BookNotFoundException("Book with id: " + id + " not found");
        }
        return new BookResponse(book.getId(), book.getTitle(), book.getAuthor());
    }

    public BookResponse create(BookRequest request) {
        if (request.title() == null || request.title().isEmpty()) {
            throw new IllegalArgumentException("Title must contain a value");
        }
        if (request.author() == null || request.author().isEmpty()) {
            throw new IllegalArgumentException("Author must contain a value");
        }

        Book book = new Book(nextId++, request.title(), request.author());
        repository.create(book);
        return new BookResponse(book.getId(), book.getTitle(), book.getAuthor());
    }
}
