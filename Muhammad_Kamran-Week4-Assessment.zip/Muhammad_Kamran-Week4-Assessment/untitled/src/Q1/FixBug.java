package Q1;

public class FixBug {

    static int arraySum(int[] arr) {
        int sum = 0;

//        Array index start from 0 and <= includes the length of the array, so we need to use only < to exclude the length of the array
//        for (int i = 0; i <= arr.length; i++) {
        for (int i = 0; i < arr.length; i++) {
            sum += arr[i];
        }
        return sum;
    }

    public static void main(String[] args) {


        int[] arr = {1,2,3,4,5,6};
        int sum = arraySum(arr);

        System.out.println("Sum of array items: " + sum);
    }
}
