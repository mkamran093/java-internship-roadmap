package Q2;

public class ReferenceAndGC {

    public static void main(String[] args) {

        String message = "This is a demo message"; // object created and message referencing to it
        String msg2 = null;
        System.out.println(message);
        message = null; // message becomes null but another reference is still present
        msg2 = null;  // now no other reference exists so it becomes eligible for GC

    }
}
