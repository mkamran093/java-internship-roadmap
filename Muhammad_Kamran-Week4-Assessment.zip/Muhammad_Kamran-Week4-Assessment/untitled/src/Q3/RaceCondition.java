package Q3;

class Counter {

    int count = 0;

    public void increment() {
        count++;
    }
}

public class RaceCondition {

    public static void main(String[] args) {

        Counter counter = new Counter();
        MyThread t1 = new MyThread(counter);
        MyThread t2 = new MyThread(counter);

        t1.start();
        t2.start();

        try {
            t1.join();
            t2.join();
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }

        System.out.println(counter.count);

        // sometimes the answer is correct and sometimes not.
        // the reason for incorrect answer is that both threads read at the same time increment and write
        // the value causing loss of progress.
        // the reason for correct output is that sometimes one thread completes the task before other
        // which preserves the correct value.
    }
}
