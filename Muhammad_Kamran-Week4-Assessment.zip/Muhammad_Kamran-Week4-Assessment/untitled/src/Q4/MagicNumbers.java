package Q4;

public class MagicNumbers {

    final static int MIN_ORDER_THRESHOLD = 5;
    final static double DISCOUNT_RATE = 0.2;

    public static double calculateDiscount(int price, int min_threshold, double discountRate) {
        return (price * min_threshold) - ((price * min_threshold) * discountRate);
    }

    public static void main(String[] args) {

        int price = 50;
        int total = 5 * 50;
        double discount = total - (total * 0.2);

        double refactoredDiscount = calculateDiscount(price, MIN_ORDER_THRESHOLD, DISCOUNT_RATE);
    }
}
