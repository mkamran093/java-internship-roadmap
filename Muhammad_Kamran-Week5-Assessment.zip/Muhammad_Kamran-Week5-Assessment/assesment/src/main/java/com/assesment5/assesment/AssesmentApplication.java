package com.assesment5.assesment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AssesmentApplication {

	public static int divide(int a, int b) {
		return a / b;
	}

	public static char getFirstChar(String input) {
		if (input == null || input.isEmpty()) {
			throw new IllegalArgumentException("input must not be null or empty");
		}
		return input.charAt(0);
	}

	public static boolean isValidAge(int age) {
		return age >= 0 && age <= 120;
	}



	public static void main(String[] args) {
		SpringApplication.run(AssesmentApplication.class, args);
	}

}
