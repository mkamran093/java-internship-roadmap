package com.assesment5.assesment;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class AssesmentApplicationTest {

    @Test
    void main() {
    }
}