package com.assesment5.assesment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AssesmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
