package com.assesment5.assesment.q1;

import com.assesment5.assesment.AssesmentApplication;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class Q1Test {

    @Test
    @DisplayName("Should return the division of 2 numbers")
    void testDivide() {
        // Happy path
        assertEquals(5, AssesmentApplication.divide(10, 2));

   }

    @Test
    @DisplayName("Should return the division of 2 numbers")
    void testEdgeCaseDivide() {

        // Edge Case
        assertEquals(-1, AssesmentApplication.divide(10, -10));
        assertEquals(0, AssesmentApplication.divide(0, 10));
}

    @Test
    @DisplayName("Should return the division of 2 numbers")
    void testFailDivide() {

        // Failure Path
        assertThrows(ArithmeticException.class, () -> AssesmentApplication.divide(10, 0));
    }


}
