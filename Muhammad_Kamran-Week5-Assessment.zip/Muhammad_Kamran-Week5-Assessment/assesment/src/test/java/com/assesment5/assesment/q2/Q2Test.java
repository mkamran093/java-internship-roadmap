package com.assesment5.assesment.q2;

import com.assesment5.assesment.AssesmentApplication;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;


public class Q2Test {

    @Test
    @DisplayName("Should return the first character of a string")
    void stringTest() {
        // happy
        assertEquals('K', AssesmentApplication.getFirstChar("Kamran"));
    }

    @Test
    @DisplayName("Should return the first character of a string")
    void stringEdgeTest() {

        // edge
        assertEquals('K', AssesmentApplication.getFirstChar("K"));
}

    @Test
    @DisplayName("Should return the first character of a string")
    void stringFailTest() {

        // Failure
        assertThrows(IllegalArgumentException.class, () -> AssesmentApplication.getFirstChar(""));
        assertThrows(IllegalArgumentException.class, () -> AssesmentApplication.getFirstChar(null));
    }
}
