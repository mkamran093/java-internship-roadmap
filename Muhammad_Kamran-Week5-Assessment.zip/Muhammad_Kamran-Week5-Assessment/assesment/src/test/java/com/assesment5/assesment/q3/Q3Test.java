package com.assesment5.assesment.q3;

import com.assesment5.assesment.AssesmentApplication;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;


public class Q3Test {

    @Test
    @DisplayName("Should tell if the a person is of valid age")
    void testNormalAge() {

        // happy path
        assertTrue(AssesmentApplication.isValidAge(18));

    }

    @Test
    @DisplayName("Should tell if the a person is of valid age")
    void testEdgeAge() {

        // edge path
        assertTrue(AssesmentApplication.isValidAge(0));
        assertTrue(AssesmentApplication.isValidAge(120));

    }

    @Test
    @DisplayName("Should tell if the a person is of valid age")
    void testWrongAge() {

        // failure path
        assertFalse(AssesmentApplication.isValidAge(-1));
        assertFalse(AssesmentApplication.isValidAge(121));

    }


}
