package com.library;

import com.library.service.BookService;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;

import java.io.IOException;

public class BooksHandler implements HttpHandler {
    private final BookService service;

    public BooksHandler(BookService service) {
        this.service = service;
    }

    @Override
    public void handle(HttpExchange exchange) throws IOException {
        String method = exchange.getRequestMethod();
        // TODO: handle supported GET behavior
        // TODO: parse optional id query parameter
        // TODO: send 404 when missing and 405 for unsupported methods
        // TODO: set Content-Type explicitly for JSON responses
    }
}

