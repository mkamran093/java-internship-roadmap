package com.library;

import com.library.repository.BookRepository;
import com.library.service.BookService;
import com.library.util.BookMapper;
import com.library.util.BookValidator;
import com.sun.net.httpserver.HttpServer;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public final class LibraryHttpServer {
    public static void main(String[] args) throws IOException {
        HttpServer server = HttpServer.create(new InetSocketAddress(8080), 0);
        // TODO: create repository, validator, mapper, service and handler objects
        server.createContext("/health", exchange -> {
            // TODO: return 200 health response

        });

        String dbUrl = "jdbc:mysql://localhost:3306/booksdb";
        String username = "root";
        String password = "root";

        try (Connection connection = DriverManager.getConnection(dbUrl, username, password)) {
            BookRepository br = new BookRepository(connection);
            BookValidator bv = new BookValidator();
            BookMapper bm = new BookMapper();
            server.createContext("/books", new BooksHandler(new BookService(br, bv, bm)));
            server.start();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }
}

