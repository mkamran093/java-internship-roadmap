package com.library.repository;

import com.library.model.Book;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class BookRepository {

    Connection connection;

    public BookRepository(Connection connection) {
        this.connection = connection;
    }

    List<Book> findAll() {
        String sql = "SELECT * FROM books";
        ArrayList<Book> books = new ArrayList<>();
        try (PreparedStatement ps = connection.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                books.add(new Book(
                        rs.getLong("id"),
                        rs.getString("title"),
                        rs.getString("author"),
                        rs.getInt("publicationYear")
                ));
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
            return null;
        }
        return books;
    }

    Optional<Book> findById(long id) {
        String sql = "SELECT * FROM books where id = ?";
        Book book;
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setLong(1, id);
            try(ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    book = new Book(
                            rs.getLong("id"),
                            rs.getString("title"),
                            rs.getString("author"),
                            rs.getInt("publicationYear")
                    );
                    return Optional.of(book);
                }
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
            return null;
        }
        return Optional.empty();
    }

    Book save(Book book) {
        String sql = "Insert into books (title, author, publicationYear) values (?, ?, ?)";
        try(PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, book.getTitle());
            ps.setString(2, book.getAuthor());
            ps.setInt(3, book.getPublicationYear());

            ps.executeUpdate();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
            return null;
        }
        return book;
    }

}
