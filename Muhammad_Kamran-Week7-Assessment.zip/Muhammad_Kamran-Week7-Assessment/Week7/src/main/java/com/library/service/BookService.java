package com.library.service;

import com.library.dto.BookRequestDTO;
import com.library.dto.BookResponseDTO;
import com.library.repository.BookRepository;
import com.library.util.BookMapper;
import com.library.util.BookValidator;

import java.util.List;

public class BookService {
    private final BookRepository repository;
    private final BookValidator validator;
    private final BookMapper mapper;

    public BookService(BookRepository repository, BookValidator validator, BookMapper mapper) {
        this.repository = repository;
        this.validator = validator;
        this.mapper = mapper;
    }

    public BookResponseDTO createBook(BookRequestDTO request) {
        // TODO: validate -> reject invalid input -> save once -> map response
        List<String> errors = validator.validate(request);
        if (errors.isEmpty()) {

        }
        BookResponseDTO response = new BookResponseDTO();
    }
}

