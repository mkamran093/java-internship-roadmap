package com.library.util;

import com.library.dto.BookRequestDTO;
import com.library.dto.BookResponseDTO;
import com.library.model.Book;

public class BookMapper {

    public Book requestToBook(BookRequestDTO request) {
        return new Book(request.getTitle(), request.getAuthor(), request.getPublicationYear());
    }

    public BookResponseDTO bookToResponse(Book book) {
        return new BookResponseDTO(book.getId(), book.getTitle(), book.getAuthor(), book.getPublicationYear());
    }

}
