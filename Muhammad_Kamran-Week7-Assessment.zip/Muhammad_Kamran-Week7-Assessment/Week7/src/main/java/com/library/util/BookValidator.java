package com.library.util;

import com.library.dto.BookRequestDTO;
import java.util.ArrayList;
import java.util.List;

public class BookValidator {
    public List<String> validate(BookRequestDTO request) {
        List<String> errors = new ArrayList<>();
        // TODO: collect ALL validation errors before returning
        String title = request.getTitle();
        String author = request.getAuthor();
        int publicationYear = request.getPublicationYear();
        int currentYear = 2026; // set with built in function

        if (title == null) {
            errors.add("Title should not be null");
        } else if (title.length() < 3 || title.length() > 50) {
            errors.add("Title length should be between 2 and 50 characters.");
        }

        if (author == null || author.isEmpty()) {
            errors.add("Author name cannot be null or empty");
        }

        if(publicationYear > currentYear) {
            errors.add("Publication year cannot be greater than the current year.");
        }

        return errors;
    }
}

