package CharacterCounter;

import java.util.Scanner;

public class CharacterCounter {

    public static void main(String args[]) {

        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter some text: ");
        String text = scanner.nextLine();
//        char[] charArray = text.toCharArray();
        int characters = 0, digits = 0, letters = 0;
        int charValue;
        char character;
        for (int i = 0; i < text.length(); i++) {
            character = text.charAt(i);
            charValue = (int)character;
            if (character != ' ') {
                characters++;
                if (charValue >= 48 && charValue <=57) digits++;
                else if (charValue >= 65 && charValue <=90) letters++;
                else if (charValue >= 97 && charValue <= 122) letters++;
            }
        }

        System.out.println("Total character excluding spaces: " + characters);
        System.out.println("Number of digits: " + digits);
        System.out.println("Number of letters: " + letters);

        scanner.close();
    }
}
