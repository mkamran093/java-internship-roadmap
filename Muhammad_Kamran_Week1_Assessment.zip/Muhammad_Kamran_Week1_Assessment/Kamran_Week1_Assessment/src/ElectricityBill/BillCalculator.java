package ElectricityBill;

import java.util.Scanner;

public class BillCalculator {

    public static double calculateBill(int units) {
        if (units < 0) {
            return -1.0;
        }
        double bill;

        if (units > 300) {
            bill = 100 * 10 + 200 * 15 + (units - 300) * 22;
        } else if (units > 100 && units <= 300) {
            bill = 100 * 10 + (units - 100) * 15;
        } else {
            bill = units * 10;
        }

        return bill;
    }

    public static void main(String args[]) {

        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter units consumed: ");
        int units = scanner.nextInt();

        double bill = calculateBill(units);

        if (bill == -1.0) {
            System.out.println("Units can't be less than zero.");
        } else {
            System.out.println("Your total payable bill is PKR " + bill);
        }

        scanner.close();

    }
}
