package MoveZeros;

public class MoveZerosToEnd {

    public static void main(String args[]) {

        int[] numbers = {4, 5, 0, 0,3, 0, 6, 3, 7, 9, 0, 4, 6};

        for (int i = 0; i < numbers.length; i++) {
            for (int j = 0; j < numbers.length; j++) {
                if (numbers[j] == 0 && j != numbers.length - 1) {
                    int helper = numbers[j];
                    numbers[j] = numbers[j + 1];
                    numbers[j + 1] = helper;
                }
            }
        }

        for (int x : numbers) {
            System.out.print(x + " ");
        }
    }
}
