package SalaryCalculator;

import java.util.Scanner;

public class SalaryCalculator {

    public static void main(String args[]) {


        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter Employee Name: ");
        String employeeName = scanner.nextLine();
        System.out.print("Enter base salary: ");
        double baseSalary = scanner.nextDouble();
        System.out.print("Enter bonus percentage: ");
        double bonusPercent = scanner.nextDouble();
        System.out.print("Enter tax percentage: ");
        double taxPercent = scanner.nextDouble();

        double bonusAmount = baseSalary * (bonusPercent / 100);
        double grossSalary = baseSalary + bonusAmount;
        double taxAmount = grossSalary * (taxPercent / 100);
        double netSalary = grossSalary - taxAmount;

        System.out.println("************************************");
        System.out.println("       Employee Salary Slip");
        System.out.println("************************************");
        System.out.println("\n\nEmployee Name:\t" + employeeName);
        System.out.println("\nGross Salary:\t" + grossSalary);
        System.out.println("\nTax Deducted:\t" + taxAmount);
        System.out.println("\nNet Salary:\t" + netSalary);

        scanner.close();
    }

}
