package UsernameNormalization;

import java.util.Scanner;

public class UsernameNormalization {

    public static StringBuilder standardizUsername (StringBuilder name) {

        String validChars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        for (int i = 0; i < name.length(); i++) {
            String character = String.valueOf((name.charAt(i)));
            if (!validChars.contains(character)) {
                name.deleteCharAt(i);
            }
        }


        for (int i = 0; i < name.length(); i++) {
            if ((i+1) % 4 == 0) {
                name.insert(i, '_');
            }
        }


        return name;
    }

    public static void main(String args[]) {

        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter a username: ");
        String input = scanner.nextLine();
        StringBuilder username = new StringBuilder(input);

        System.out.println("Your Standardized username is " + standardizUsername(username));

        scanner.close();
    }
}
