package Exceptions;

public class BookNotAvailableExceptions extends Exception {

    public BookNotAvailableExceptions(String message) {
        super(message);
    }
}
