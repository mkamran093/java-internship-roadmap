package Exceptions;

public class DuplicateMemberException extends Exception {

    public DuplicateMemberException(String message) {
        super(message);
    }
}
