public class FacultyMember extends Member implements Notifiable {

    public FacultyMember(String memberId, String name, String email) {
        super(memberId, name, email);
    }

    public void notify(String message) {

    }

    public int getBorrowLimit(){
        return 6;
    }
}
