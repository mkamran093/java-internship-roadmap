import Exceptions.*;

import java.util.*;

public class Library {

    private Map<String, Book> books = new HashMap<>();
    private Map<String, Member> members = new HashMap<>();
    private Set<String> memberIds = new HashSet<>();
    private Map<String, List<String>> borrowedIsbns = new HashMap<>();

    public void addMember(Member member) throws DuplicateMemberException{
        if(memberIds.contains(member.getMemberId())) {
            throw new DuplicateMemberException("Member with ID " + member.getMemberId() + " Already Exists");
        }
        members.put(member.getMemberId(), member);
        borrowedIsbns.put(member.getMemberId(), null);
    }

    public void addBook(Book book) throws DuplicateIsbnException {
        if(books.containsKey(book.getIsbn())) {
            throw new DuplicateIsbnException("A book with same isbn already exists");
        }
        books.put(book.getIsbn(), book);
    }

    public void issueBook(String memberId, String isbn) throws
            BookNotFoundException,
            BookNotAvailableExceptions,
            BorrowLimitExceededException {
        if (memberId == null || isbn == null || memberId.isEmpty() || isbn.isEmpty()) {
            System.out.println("Invalid input");
            return;
        }
        if (!books.containsKey(isbn)) {
            throw new BookNotFoundException("Book with ISBN: " + isbn + " not found");
        }

        if (books.get(isbn).getAvailableCopies() == 0) {
            throw new BookNotAvailableExceptions("All copies are issued currently");
        }
        if (borrowedIsbns.get(memberId).size() == members.get(memberId).getBorrowLimit()) {
            throw new BorrowLimitExceededException("This member has exceeded their borrow limit");
        }

        books.get(isbn).issueCopy();
        borrowedIsbns.get(memberId).add(isbn);

    }

    public void returnBook(String memberId, String isbn) {
        if (!borrowedIsbns.get(memberId).contains(isbn)) {
            System.out.println("This book has not been issued to this member");
        }
        books.get(isbn).returnBook();
        borrowedIsbns.get(memberId).remove(isbn);
    }
}
