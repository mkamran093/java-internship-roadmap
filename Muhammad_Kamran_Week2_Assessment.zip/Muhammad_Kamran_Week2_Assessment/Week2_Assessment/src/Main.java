import Exceptions.*;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {

        Member m1 = new StudentMember("1", "Kamran", "email@gmailc.om");
        Member m2 = new FacultyMember("2", "Inzamam", "email@gmailc.om");

        Book b1 = new Book("101", "Title1", "Good author", 5, 5);
        Book b2 = new Book("102", "Title1", "Good author", 5, 5);
        Book b3 = new Book("103", "Title1", "Good author", 5, 5);
        Book b4 = new Book("104", "Title1", "Good author", 1, 1);

        Library library = new Library();

        try{

            library.addMember(m1);
            library.addMember(m2);
            library.addBook(b1);
            library.addBook(b2);
            library.addBook(b3);
            library.addBook(b4);

            library.issueBook(m1.getMemberId(), b1.getIsbn());

        } catch (BorrowLimitExceededException | BookNotAvailableExceptions | BookNotFoundException | DuplicateMemberException | DuplicateIsbnException e) {
            System.out.println(e.getMessage());
        }

    }
}