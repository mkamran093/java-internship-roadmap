public class StudentMember extends Member implements Notifiable {

    public StudentMember(String memberId, String name, String email) {
        super(memberId, name, email);
    }

    public void notify(String message) {
        System.out.println(message);
    }

    public int getBorrowLimit() {
        return 3;
    }
}
