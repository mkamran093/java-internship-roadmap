import java.sql.Struct;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {

        List<Student> students = new ArrayList<>();

        Student s1 = new Student("Kamran", 86, "CS");
        Student s2 = new Student("Ali", 62, "AF");
        Student s3 = new Student("Sara", 98, "EE");
        Student s4 = new Student("Ahmed", 59, "CS");
        Student s5 = new Student("Abdullah", 20, "BBA");
        Student s6 = new Student("Saad", 58, "EE");
        Student s7 = new Student("Majid", 78, "CS");
        Student s8 = new Student("Ibrar", 18, "BBA");

        students.add(s1);
        students.add(s2);
        students.add(s3);
        students.add(s4);
        students.add(s5);
        students.add(s6);
        students.add(s7);
        students.add(s8);

        List<String> passedStudents = students.stream()
                .filter(s -> s.getMarks() >= 40)
                .map(Student::getName)
                .collect(Collectors.toList());

        System.out.println("Passed students");
        System.out.println(passedStudents);

        System.out.println("\nOrdered by marks");
        students.stream()
                .sorted(Comparator.comparing(Student::getMarks).reversed())
                .forEach(System.out::println);

        List<String> names = students.stream()
                .map(Student::getName)
                .collect(Collectors.toList());
        System.out.println("\n Student names");
        System.out.println(names);

        Map<String, List<Student>> byDepartment = students.stream()
                        .collect(Collectors.groupingBy(student -> student.getDepartment()));
        System.out.println("Grouped by department");
        System.out.println(byDepartment);

        System.out.println("\nTop Scoring student");
        Student highestScoring = students.stream()
                .sorted(Comparator.comparing(Student::getMarks).reversed())
                .findFirst().get();
        System.out.println(highestScoring);

    }
}